Project:  Universal Termsrv.dll Patch
Support:  Windows XP SP2 SP3; Vista SP1 SP2/Windows 7,  32bit(x86)/64bit(x64)
Blog:     http://deepxw.blogspot.com (English) || http://deepxw.lingd.net

Crack termsrv.dll, remove the Concurrent Remote Desktop sessions limit, allow multi-user login in XP/Vista at the same time.

This is only a file patch for termsrv.dll.
More setting for RDP, please google it.

The meaning of the last number of checksum:
1 - Original file, without any modification.
9 - The file has been modified.

Notes:
1, Can oprate in normal mode. Do not need to enter safe mode.

2, Choose the corresponding patcher based on you Windows:
   For 32bit(x86):   UniversalTermsrvPatch-x86.exe
   For 64bit(amd64): UniversalTermsrvPatch-x64.exe

3, Require administrator rights. Right-click the exe file, select Run as Administrator.

4, After patch, Restart computer to take effect.

5, Backup file: \windows\system32\termsrv.dll.backup.

History:

2009.04.16 V1.0
  + First release.

2009.04.25 V1.0b
  * Fix a bug in xp.reg. Thanks godolphinaim!